<?php
  $conn = mysqli_connect('localhost','root','');
  mysqli_select_db($conn,'tbk');
  $$conn->set_charset("utf8");
?>